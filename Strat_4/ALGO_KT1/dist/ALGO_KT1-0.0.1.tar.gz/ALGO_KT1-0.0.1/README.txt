This is a list of some very basic functions for finance.
